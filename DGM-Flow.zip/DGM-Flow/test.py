import time
from options.train_options import TrainOptions
from models.networks import VGGLoss, save_checkpoint
from models.afwm7_gcn import TVLoss, AFWM
import torch.nn as nn
import torch.nn.functional as F
import os
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from tensorboardX import SummaryWriter
import cv2
from data.data_loader import CreateDataLoader
from models.networks import ResUnetGenerator, load_checkpoint
import datetime

opt = TrainOptions().parse()
path = 'runs/' + opt.name
os.makedirs(path, exist_ok=True)


def CreateDataset(opt):
    from data.aligned_dataset import AlignedDataset
    dataset = AlignedDataset()
    print("dataset [%s] was created" % (dataset.name()))
    dataset.initialize(opt)
    return dataset


data_loader = CreateDataLoader(opt)
dataset = data_loader.load_data()
dataset_size = len(data_loader)
print(dataset_size)

warp_model = AFWM(opt, 45)
print(warp_model)
warp_model.train()
warp_model.cuda()




checkpoint = torch.load('DGM_warp_epoch_101.pth')
load_checkpoint(warp_model, 'ours.pth')

gen_model = ResUnetGenerator(7, 4, 5, ngf=64, norm_layer=nn.BatchNorm2d)
print(gen_model)
gen_model.eval()
gen_model.cuda()
load_checkpoint(gen_model, 'checkpoints/DGM/gen_model_final.pth')

for i, data in enumerate(dataset):
    save_fake = True

    t_mask = torch.FloatTensor((data['label'].cpu().numpy() == 7).astype(np.float))
    data['label'] = data['label'] * (1 - t_mask) + t_mask * 4
    edge = data['edge']
    pre_clothes_edge = torch.FloatTensor((edge.detach().numpy() > 0.5).astype(np.int))
    clothes = data['color']
    clothes = clothes * pre_clothes_edge
    person_clothes_edge = torch.FloatTensor((data['label'].cpu().numpy() == 4).astype(np.int))
    real_image = data['image']
    person_clothes = real_image * person_clothes_edge
    pose = data['pose']
    size = data['label'].size()
    oneHot_size1 = (size[0], 25, size[2], size[3])
    densepose = torch.cuda.FloatTensor(torch.Size(oneHot_size1)).zero_()
    densepose = densepose.scatter_(1, data['densepose'].data.long().cuda(), 1.0)
    densepose_fore = data['densepose'] / 24.0
    face_mask = torch.FloatTensor((data['label'].cpu().numpy() == 1).astype(np.int)) + torch.FloatTensor(
        (data['label'].cpu().numpy() == 12).astype(np.int))
    other_clothes_mask = torch.FloatTensor((data['label'].cpu().numpy() == 5).astype(np.int)) + torch.FloatTensor(
        (data['label'].cpu().numpy() == 6).astype(np.int)) + \
                         torch.FloatTensor((data['label'].cpu().numpy() == 8).astype(np.int)) + torch.FloatTensor(
        (data['label'].cpu().numpy() == 9).astype(np.int)) + \
                         torch.FloatTensor((data['label'].cpu().numpy() == 10).astype(np.int))
    preserve_mask = torch.cat([face_mask, other_clothes_mask], 1)
    concat = torch.cat([preserve_mask.cuda(), densepose, pose.cuda()], 1)

    flow_out = warp_model(concat.cuda(), clothes.cuda(), pre_clothes_edge.cuda())
    warped_cloth, last_flow, _1, _2, delta_list, x_all, x_edge_all, delta_x_all, delta_y_all, x_mask = flow_out

    warped_prod_edge = x_edge_all[3]

    warped_edge = F.grid_sample(edge.cuda(), last_flow.permute(0, 2, 3, 1),
                                mode='bilinear', padding_mode='zeros')

    gen_inputs = torch.cat([real_image.cuda(), warped_cloth, warped_edge], 1)
    gen_outputs = gen_model(gen_inputs)
    p_rendered, m_composite = torch.split(gen_outputs, [3, 1], 1)
    p_rendered = torch.tanh(p_rendered)
    m_composite = torch.sigmoid(m_composite)
    m_composite = m_composite * warped_edge
    p_tryon = warped_cloth * m_composite + p_rendered * (1 - m_composite)


    a = real_image.float().cuda()
    # b = person_clothes.cuda()
    c = clothes.cuda()
    # d = torch.cat([densepose_fore.cuda(), densepose_fore.cuda(), densepose_fore.cuda()], 1)
    e = p_tryon
    s = x_mask
    # print(x_mask[0][0][0].shape)
    mask = torch.cat([s.cuda(), s.cuda(), s.cuda()], 1)
    # f = torch.cat([warped_prod_edge, warped_prod_edge, warped_prod_edge], 1)
    # print(a.shape, b.shape, c.shape, e.shape)
    combine = mask.squeeze()
    # print(combine.shape)
    cv_img = (combine.permute(1, 2, 0).detach().cpu().numpy() + 1) / 2
    # writer.add_image('combine', (combine.data + 1) / 2.0, step)
    rgb = (cv_img * 255).astype(np.uint8)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


    cv2.imwrite('result/mask/' + str(i) + 'm.jpg', bgr)

    # train_sampler.set_epoch(epoch)


