import os
from PIL import Image
from torch.utils.data import Dataset



class AlignedDataset(Dataset):
    def __init__(self, root, root2, root3, root4, transform):
        self.root = root
        self.root2 = root2
        self.root3 = root3
        self.root4 = root4


        self.images = []  # 图像路径集合
        for path1 in os.listdir(self.root):
            self.images.append(Image.open(os.path.join(self.root, path1)).convert('RGB'))
        self.images2 = []
        for path2 in os.listdir(self.root2):
            self.images2.append(Image.open(os.path.join(self.root2, path2)).convert('RGB'))
        self.images3 = []
        for path3 in os.listdir(self.root3):
            self.images3.append(Image.open(os.path.join(self.root3, path3)).convert('RGB'))
        self.images4 = []
        for path4 in os.listdir(self.root4):
            self.images4.append(Image.open(os.path.join(self.root4, path4)).convert('RGB'))

        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, item):
        # image_path = self.images[item]  # 图像索引，获取单张图像路径
        # image = Image.open(image_path).convert('RGB')

        real1 = self.images[item]
        real2 = self.images2[item]
        pose1 = self.images3[item]  # 图像索引，获取单张图像路径
        pose2 = self.images4[item]


        # image2 = Image.open(image_path2).convert('RGB')
        # _, image_name = os.path.split(image_path)
        # label, _ = image_name.split('.')
        # # label = label[:-5]

        if self.transform is not None:
            real1 = self.transform(real1)
            real2 = self.transform(real2)
            pose1 = self.transform(pose1)
            pose2 = self.transform(pose2)

        return real1, real2, pose1, pose2